package com.example.icasapp.Home

// Create a new user
//fun createUser(name: String, sem: String, stream: String): Boolean {
//    val user = hashMapOf(
//            "name" to name,
//            "semester" to sem,
//            "stream" to stream)
//
//    // addDocumentToCollection(user, "USER")
//    return true
//}





