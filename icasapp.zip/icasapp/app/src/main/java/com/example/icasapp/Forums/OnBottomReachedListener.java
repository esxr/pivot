package com.example.icasapp.Forums;

public interface OnBottomReachedListener {
    void OnBottomReached(int position);
}
