package com.example.icasapp.Annonations;

public @interface Hardcoded {
}