package com.example.icasapp.User;

public class Privilage {
    public int level;

    public Privilage(int level) {
        this.level = level;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
}
