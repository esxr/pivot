package com.example.icasapp.Notes;

public class Notes {

    private String name;
    private String semester;
    private String sessional;
    private String author;
    private String downloadURL;

    public Notes(){

    }

    public Notes(String name, String semester, String sessional, String author, String downloadURL) {
        this.name = name;
        this.semester = semester;
        this.sessional = sessional;
        this.author = author;
        this.downloadURL = downloadURL;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getSessional() {
        return sessional;
    }

    public void setSessional(String sessional) {
        this.sessional = sessional;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDownloadURL() {
        return downloadURL;
    }

    public void setDownloadURL(String downloadURL) {
        this.downloadURL = downloadURL;
    }
}
