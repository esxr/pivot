package com.example.icasapp.Notes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.icasapp.R;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class NotesAdapter extends FirestoreRecyclerAdapter<Notes, NotesAdapter.NotesHolder> {
    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public NotesAdapter(@NonNull FirestoreRecyclerOptions<Notes> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull NotesHolder notesHolder, int i, @NonNull Notes notes) {
        notesHolder.inputName.setText(notes.getName());
        notesHolder.semesterInput.setText("SEM:" +notes.getSemester());
        notesHolder.sessionalInput.setText("SES:"+notes.getSessional());
        notesHolder.authorName.setText("AUTHOR:"+notes.getAuthor());

    }

    @NonNull
    @Override
    public NotesHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.notes_cardview, parent, false);
        return new NotesHolder(v);
    }

    class NotesHolder extends RecyclerView.ViewHolder{
        TextView inputName;
        TextView sessionalInput;
        TextView semesterInput;
        TextView authorName;
        Button downloadButton;
        Button deleteButton;

        public NotesHolder(@NonNull View itemView) {
            super(itemView);

            inputName = itemView.findViewById(R.id.fileName);
            semesterInput = itemView.findViewById(R.id.semesterInput);
            sessionalInput = itemView.findViewById(R.id.sessionalInput);
            authorName = itemView.findViewById(R.id.authorName);
            downloadButton = itemView.findViewById(R.id.downloadButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);

        }
    }
}

